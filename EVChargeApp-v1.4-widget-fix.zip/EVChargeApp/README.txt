EV 80% Charge v1.4
Saved sessions are restored from both widget and launcher entry points. Opening the app never starts a new calculation. New Calculate presses replace the existing alarm. Changing rate affects future sessions only. Cancelling an alarm retains the saved calculation.
The alarm is a one-time notification sound, not a repeating Clock alarm. Grant Notifications and Alarms & reminders. Sound depends on volume, channel, and DND settings. Reboot rescheduling is supported where Android allows it; force-stopping or revoking alarm permissions can prevent delivery.
Build: upload this ZIP as the only ZIP in your existing repository root. Keep the existing ZIP-extraction workflow unchanged. Download the completed APK artifact. Source and XML checked, but APK not compiled/tested here.
