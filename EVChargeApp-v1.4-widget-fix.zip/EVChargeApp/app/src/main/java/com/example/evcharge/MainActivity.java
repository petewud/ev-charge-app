package com.example.evcharge;
import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.util.Locale;

public class MainActivity extends Activity {
 EditText battery,rate; TextView target,details,status; Button cancel; LinearLayout settings;
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
 TextView text(LinearLayout l,String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(6),0,dp(6));l.addView(v);return v;}
 Button button(LinearLayout l,String s){Button b=new Button(this);b.setText(s);l.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;}
 EditText input(LinearLayout l,String hint){EditText e=new EditText(this);e.setInputType(8194);e.setSingleLine(true);e.setTextColor(Color.WHITE);e.setTextSize(20);e.setHint(hint);e.setHintTextColor(0xff94a3b8);l.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 @Override public void onCreate(Bundle b){super.onCreate(b);Session.channel(this);
 ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff0f172a);
 LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(24),dp(24),dp(24),dp(24));scroll.addView(l);setContentView(scroll);
 text(l,"EV 80% charge time",24,Color.WHITE);text(l,"Current EV battery percentage (%)",14,0xff94a3b8);battery=input(l,"42");
 button(l,"Calculate & set alarm").setOnClickListener(v->calculate());
 settings=new LinearLayout(this);settings.setOrientation(1);
 button(l,"Charging settings").setOnClickListener(v->settings.setVisibility(settings.getVisibility()==View.GONE?View.VISIBLE:View.GONE));
 l.addView(settings);text(settings,"Charging rate (% per hour)",14,0xff94a3b8);rate=input(settings,"16");rate.setText(""+Session.prefs(this).getFloat("charge_rate",16f));
 button(settings,"Save rate").setOnClickListener(v->{try{float r=Float.parseFloat(rate.getText().toString());if(!Float.isFinite(r)||r<=0||r>100)throw new Exception();Session.prefs(this).edit().putFloat("charge_rate",r).apply();settings.setVisibility(View.GONE);toast("Rate saved. Existing sessions are unchanged.");}catch(Exception e){toast("Enter a rate above 0 and up to 100");}});settings.setVisibility(View.GONE);
 text(l,"Estimated 80% time",14,0xff94a3b8);target=text(l,"--:--",36,0xff4ade80);details=text(l,"",15,0xffe2e8f0);status=text(l,"",14,0xff4ade80);
 cancel=button(l,"Cancel charge alarm");cancel.setOnClickListener(v->{Session.cancel(this);restore(false);ChargeWidgetProvider.refresh(this);});
 button(l,"Alarm permissions & sound settings").setOnClickListener(v->{if(!Session.notifications(this)){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}else if(!Session.exact(this)){requestExact();}else startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,Session.CHANNEL));});
 text(l,"Estimate only — not connected to your car. Sound plays once, not a repeating Clock alarm. Check alarm volume and Do Not Disturb settings.",13,0xff94a3b8);restore(true);
 }
 @Override protected void onResume(){super.onResume();if(target!=null)restore(false);}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);restore(true);}
 void restore(boolean restoreInput){
 android.content.SharedPreferences p=Session.prefs(this);long t=p.getLong("session_target",p.getLong("alarm_target",0));long start=p.getLong("session_start",p.getLong("alarm_start",0));
 float b=p.getFloat("session_battery",p.getFloat("alarm_battery",0));float r=p.getFloat("session_rate",p.getFloat("charge_rate",16));
 if(t==0){target.setText("--:--");details.setText("Enter the battery level to start a charging session.");}else{
 if(restoreInput)battery.setText(String.format(Locale.getDefault(),"%s",b));
 target.setText(Session.time(this,t));long mins=Math.round(Math.max(0,t-start)/60000.0);
 details.setText("From "+b+"% at "+r+"% per hour\nStarted "+Session.time(this,start)+" · "+(mins/60)+" hr "+(mins%60)+" min"+(t<=System.currentTimeMillis()?"\nEstimated target time reached.":""));}
 long alarm=p.getLong("alarm_trigger",0);status.setText(alarm>System.currentTimeMillis()?Session.schedule(this):"No upcoming alarm. Saved calculation retained.");cancel.setVisibility(alarm>System.currentTimeMillis()?View.VISIBLE:View.GONE);
 }
 void calculate(){try{
 double b=Double.parseDouble(battery.getText().toString());if(!Double.isFinite(b)||b<0||b>80)throw new Exception();
 float r=Session.prefs(this).getFloat("charge_rate",16);long now=System.currentTimeMillis();long t=now+Math.round((80-b)/r*3600000.0);
 Session.cancel(this);
 Session.prefs(this).edit().putLong("session_start",now).putLong("session_target",t).putFloat("session_battery",(float)b).putFloat("session_rate",r).apply();
 if(t>now)Session.prefs(this).edit().putLong("alarm_trigger",t).apply();
 ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(80);restore(true);ChargeWidgetProvider.refresh(this);
 if(t>now){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);else if(!Session.exact(this))requestExact();}
 }catch(Exception e){toast("Enter a battery percentage from 0 to 80");}}
 void requestExact(){if(Build.VERSION.SDK_INT>=31)try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){toast("Allow Alarms & reminders in app settings");}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.length>0&&g[0]==0&&!Session.exact(this))requestExact();restore(false);}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
