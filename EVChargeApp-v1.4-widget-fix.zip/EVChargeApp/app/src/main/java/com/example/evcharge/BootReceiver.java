package com.example.evcharge;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){Session.schedule(c);ChargeWidgetProvider.refresh(c);}
}
