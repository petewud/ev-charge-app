package com.example.evcharge;
import android.app.*;
import android.content.*;
import android.os.Build;
import android.media.*;
import android.provider.Settings;
import java.util.Date;

public class Session {
 static final String PREFS="ev_charge_settings", CHANNEL="ev_charge_alarm_v1";
 static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,0);}
 static String time(Context c,long t){return android.text.format.DateFormat.getTimeFormat(c).format(new Date(t));}
 static PendingIntent alarm(Context c){return PendingIntent.getBroadcast(c,80,new Intent(c,AlarmReceiver.class).setAction("com.example.evcharge.CHARGE_COMPLETE"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static PendingIntent open(Context c){return PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static AlarmManager am(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||am(c).canScheduleExactAlarms();}
 static boolean notifications(Context c){return (Build.VERSION.SDK_INT<33||c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0)&&((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).areNotificationsEnabled();}
 static void channel(Context c){
 NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
 if(n.getNotificationChannel(CHANNEL)!=null)return;
 NotificationChannel ch=new NotificationChannel(CHANNEL,"80% charge alarm",NotificationManager.IMPORTANCE_HIGH);
 ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
 ch.enableVibration(true);n.createNotificationChannel(ch);
 }
 static boolean channelOn(Context c){channel(c);return ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).getNotificationChannel(CHANNEL).getImportance()!=NotificationManager.IMPORTANCE_NONE;}
 static String schedule(Context c){
 long t=prefs(c).getLong("alarm_trigger",0);
 if(t<=System.currentTimeMillis())return "No upcoming alarm.";
 if(!notifications(c)||!channelOn(c))return "Alarm not set: allow notifications and the 80% charge alarm channel.";
 if(!exact(c))return "Alarm not set: allow Alarms & reminders, then return here.";
 try{am(c).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,alarm(c));return "Alarm set for "+time(c,t)+" (sound notification).";}
 catch(SecurityException e){return "Alarm permission unavailable. Enable Alarms & reminders.";}
 }
 static void cancel(Context c){am(c).cancel(alarm(c));prefs(c).edit().remove("alarm_trigger").apply();}
}
