package com.example.evcharge;
import android.app.*;
import android.content.*;
public class AlarmReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
 if(Session.prefs(c).getLong("alarm_trigger",0)==0)return;
 Session.prefs(c).edit().remove("alarm_trigger").apply();ChargeWidgetProvider.refresh(c);
 if(!Session.notifications(c)||!Session.channelOn(c))return;
 Notification n=new Notification.Builder(c,Session.CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("EV estimated at 80%").setContentText("Estimated charging time reached. Check your vehicle.").setCategory(Notification.CATEGORY_ALARM).setAutoCancel(true).setContentIntent(Session.open(c)).build();
 ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(80,n);
 }
}
