package com.example.evcharge;
import android.appwidget.*;
import android.content.*;
import android.os.Bundle;
import android.widget.RemoteViews;
public class ChargeWidgetProvider extends AppWidgetProvider {
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
 public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){update(c,m,id);}
 static void update(Context c,AppWidgetManager m,int id){
 android.content.SharedPreferences p=Session.prefs(c);
 long t=p.getLong("session_target",p.getLong("alarm_target",0));
 float b=p.getFloat("session_battery",p.getFloat("alarm_battery",0));
 Bundle opts=m.getAppWidgetOptions(id);int height=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,80);
 RemoteViews v=new RemoteViews(c.getPackageName(),height>=115?R.layout.widget_large:R.layout.widget_compact);
 v.setTextViewText(R.id.widget_time,t==0?"--:--":Session.time(c,t));
 String detail=t==0?"Tap to start":(t<=System.currentTimeMillis()?"Target reached":"From "+b+"%");
 v.setTextViewText(R.id.widget_detail,detail);
 if(height>=115)v.setTextViewText(R.id.widget_extra,p.getLong("alarm_trigger",0)>System.currentTimeMillis()?"Alarm scheduled · tap to view":"Tap to view saved session");
 v.setOnClickPendingIntent(R.id.widget_root,Session.open(c));m.updateAppWidget(id,v);
 }
 static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(int id:m.getAppWidgetIds(new ComponentName(c,ChargeWidgetProvider.class)))update(c,m,id);}
}
