package com.example.evcharge
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var settingsPanel: View
    private lateinit var rateInput: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("ev_charge_settings", Context.MODE_PRIVATE)
        val input = findViewById<EditText>(R.id.batteryInput)
        val button = findViewById<Button>(R.id.calculateButton)
        val time = findViewById<TextView>(R.id.resultText)
        val details = findViewById<TextView>(R.id.resultDetails)
        val settingsButton = findViewById<Button>(R.id.settingsButton)
        val saveButton = findViewById<Button>(R.id.saveSettingsButton)
        settingsPanel = findViewById(R.id.settingsPanel); rateInput = findViewById(R.id.rateInput)
        rateInput.setText(prefs.getFloat("charge_rate", 16f).toString())
        settingsPanel.visibility = View.GONE
        settingsButton.setOnClickListener { settingsPanel.visibility = if (settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        saveButton.setOnClickListener {
            val rate = rateInput.text.toString().toFloatOrNull()
            if (rate == null || rate <= 0f) { Toast.makeText(this, "Enter a charging rate above 0", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            prefs.edit().putFloat("charge_rate", rate).apply()
            Toast.makeText(this, "Saved: $rate% per hour", Toast.LENGTH_SHORT).show(); settingsPanel.visibility = View.GONE
        }
        button.setOnClickListener {
            val value = input.text.toString().toDoubleOrNull()
            val rate = prefs.getFloat("charge_rate", 16f).toDouble()
            if (value == null || value < 0.0 || value > 80.0) { Toast.makeText(this, "Enter a percentage between 0 and 80", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val hours = (80.0 - value) / rate
            val target = Calendar.getInstance().apply { add(Calendar.MILLISECOND, (hours * 3600000).toInt()) }
            val targetText = DateFormat.getTimeFormat(this).format(target.time)
            val mins = Math.round(hours * 60); val h = mins / 60; val m = mins % 60
            val duration = if (h > 0) "$h hr $m min" else "$m min"
            time.text = targetText
            details.text = "From ${value}% at ${rate}% per hour — about $duration from now."
            val intent = Intent(this, ChargeWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(ChargeWidgetProvider.EXTRA_TARGET_TIME, targetText); putExtra(ChargeWidgetProvider.EXTRA_DURATION, duration)
            }
            sendBroadcast(intent)
            val manager = AppWidgetManager.getInstance(this)
            val ids = manager.getAppWidgetIds(ComponentName(this, ChargeWidgetProvider::class.java))
            ChargeWidgetProvider.updateAllWidgets(this, manager, ids, targetText, duration)
        }
    }
}
