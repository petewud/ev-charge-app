package com.example.evcharge
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
class ChargeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { updateAllWidgets(context, manager, ids, "--:--", "Open app and calculate") }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val target = intent.getStringExtra(EXTRA_TARGET_TIME); val duration = intent.getStringExtra(EXTRA_DURATION)
        if (target != null && duration != null) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ChargeWidgetProvider::class.java))
            updateAllWidgets(context, manager, ids, target, duration)
        }
    }
    companion object {
        const val EXTRA_TARGET_TIME = "target"; const val EXTRA_DURATION = "duration"
        fun updateAllWidgets(context: Context, manager: AppWidgetManager, ids: IntArray, target: String, duration: String) {
            for (id in ids) {
                val views = RemoteViews(context.packageName, R.layout.charge_widget).apply {
                    setTextViewText(R.id.widgetTargetTime, target); setTextViewText(R.id.widgetDetails, duration)
                    val open = Intent(context, MainActivity::class.java)
                    val pending = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    setOnClickPendingIntent(R.id.widgetRoot, pending)
                }
                manager.updateAppWidget(id, views)
            }
        }
    }
}
